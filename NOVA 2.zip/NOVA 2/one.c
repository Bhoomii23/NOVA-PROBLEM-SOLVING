#include <stdio.h>

int main() {
    int a, b;
    scanf("%d %d", &a, &b);
    // Your code goes here (if needed)
    int sum,product;
   // int product=0;
    sum=a+b;
    product = a*b;
    int totalsum;
    totalsum=sum+product;
    //printf("%d",totalsum);
    if(totalsum==111){
        printf("Yes");
    }
    else{
        printf("No");
    }
   
    
        
    }