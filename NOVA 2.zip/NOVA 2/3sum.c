
// Helper function for qsort to sort integers in ascending order
int compare(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

int threeSumClosest(int* nums, int numsSize, int target) {
    // Sort the array
    qsort(nums, numsSize, sizeof(int), compare);
    
    // Initialize the closest sum with the sum of the first three elements
    int closestSum = nums[0] + nums[1] + nums[2];
    
    // Iterate through the array
    for (int i = 0; i < numsSize - 2; i++) {
        int left = i + 1; // Pointer to the element next to nums[i]
        int right = numsSize - 1; // Pointer to the last element
        
        while (left < right) {
            int currentSum = nums[i] + nums[left] + nums[right];
            
            // Update the closest sum if the current sum is to the target
            if (abs(target - currentSum) < abs(target - closestSum)) {
                closestSum = currentSum;
            }
            
            // Adjust the pointers based on the current sum
            if (currentSum < target) {
                left++; // Move the left pointer to increase the sum
            } else {
                right--; // Move the right pointer to decrease the sum
            }
        }
    }
    
    return closestSum;
}
