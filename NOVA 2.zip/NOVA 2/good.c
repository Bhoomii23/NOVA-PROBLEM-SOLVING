#include <stdio.h>

int main() {
    int t;
    scanf("%d", &t);

    // Loop for each test case
    while (t--) {
        int x, y, z;

      
        scanf("%d %d", &x, &y);
        z=x+y;
        
        if(z<=6){
            printf("NO\n");
        }
        else{
            printf("YES\n");
        }

        // Your code for each test case goes here 
    }
}
