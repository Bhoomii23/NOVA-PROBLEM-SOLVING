#include <stdio.h>

int main() {
    int num;
 
    scanf("%d", &num);
    // Complete the code
    while(num !=0){
        if(num%1==0){
            else if(num%num==0)
            printf("YES");
        }
    }
    else{
        printf("NO");
    }
    
    return 0;
}
