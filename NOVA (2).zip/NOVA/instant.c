#include <stdio.h>

int main() {
	// your code goes here
	
	int x,y;
	scanf("%d",&x);
	scanf("%d",&y);
	int sum=0;
	sum=x*y;
	printf("%d",sum);

}

