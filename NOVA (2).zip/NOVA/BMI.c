#include <stdio.h>

int main() {
    float height = 1.82;
    float weight = 72;
    // Complete the code
    float BMI;
    BMI=weight/(height*height);
    printf("%f",BMI);
    return 0;
}
