int lengthOfLastWord(char* s) {
    int len = strlen(s);
    int count = 0;
    bool flag = false;
    for (int i = len - 1; i >= 0; i--) {
        if (flag && s[i] == ' ') {
            break;
        }
        if ((65 <= s[i] && s[i] <= 90) || (97 <= s[i] && s[i] <= 122)) {
            flag = true;
            count++;
        }
    }
    return count;
}