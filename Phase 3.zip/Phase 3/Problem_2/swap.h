#ifndef SWAP_H
#define SWAP_H

void swapValues(int &a, int &b);

#endif
