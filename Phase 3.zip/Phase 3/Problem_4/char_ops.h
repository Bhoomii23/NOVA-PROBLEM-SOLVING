#ifndef CHAR_OPS_H
#define CHAR_OPS_H

void toUpperCase(char* str);
void removeVowels(char* str);
void reverseString(char* str);

#endif
