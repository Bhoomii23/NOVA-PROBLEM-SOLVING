#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H

void inputArray(int* arr, int size);
void sortArray(int* arr, int size);
void printArray(int* arr, int size);

#endif
