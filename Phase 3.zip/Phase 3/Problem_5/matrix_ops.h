#ifndef MATRIX_OPS_H
#define MATRIX_OPS_H

void printMatrix(int arr[3][3]);
void transposeMatrix(int arr[3][3]);

#endif
