#include <stdio.h>

int main() {
	// your code goes here
	int language;
	int total;
	scanf("%d",&language);
	total=language*2;
	printf("%d",total);
	return 0;
	
}